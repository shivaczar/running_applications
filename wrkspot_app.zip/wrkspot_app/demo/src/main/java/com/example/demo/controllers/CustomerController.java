package com.example.demo.controllers;


import com.example.demo.model.Customer;
import com.example.demo.model.CustomerWrapper;
import com.example.demo.service.interfaces.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping(value = "customers")
    public ResponseEntity<Object> createCustomers(@RequestBody List<CustomerWrapper> customerWrappers) {
        List<Customer> customers = customerWrappers.stream()
                .map(CustomerWrapper::getCustomer)
                .collect(Collectors.toList());
        try {
            Flux<Customer> createdCustomers = customerService.createCustomers(customers);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdCustomers.collectList().block());
        } catch (Exception e) {
            String errorMessage = "Failed to create customers: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
        }
    }

    @GetMapping(value = "customers")
    public ResponseEntity<List<Customer>> getCustomers(
            @RequestParam(required = false) String firstName,
            @RequestParam(required = false) String lastName,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String state) {
        System.out.println("$$$$$$$$$$$$$$  firstName"+ firstName);
        Flux<Customer> customers = customerService.getCustomers(firstName, lastName, city, state);
        return new ResponseEntity<>(customers.collectList().block(), HttpStatus.OK);
    }
}


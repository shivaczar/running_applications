package com.example.demo.repository;

import com.example.demo.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

import java.util.List;


@Repository
public interface CustomerRepository extends ReactiveMongoRepository<Customer, String> {
    Flux<Customer> findByFirstName(String firstName);
    Flux<Customer> findByLastName(String lastName);
    Flux<Customer> findByAddressCity(String city);
    Flux<Customer> findByAddressState(String state);
}

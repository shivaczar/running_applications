package com.example.demo.controllers;


import com.example.demo.model.Customer;
import com.example.demo.model.CustomerLists;
import com.example.demo.service.interfaces.CustomerListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer-list")
public class CustomerListController {

    @Autowired
    private CustomerListService customerListService;

    @PostMapping("/only-in-a")
    public ResponseEntity<List<Customer>> getCustomersOnlyInListA(@RequestBody CustomerLists customerLists) {
        List<Customer> customersOnlyInA = customerListService.findCustomersOnlyInListA(customerLists.getListA(), customerLists.getListB());
        return new ResponseEntity<>(customersOnlyInA, HttpStatus.OK);
    }

    @PostMapping("/only-in-b")
    public ResponseEntity<List<Customer>> getCustomersOnlyInListB(@RequestBody CustomerLists customerLists) {
        List<Customer> customersOnlyInB = customerListService.findCustomersOnlyInListB(customerLists.getListA(), customerLists.getListB());
        return new ResponseEntity<>(customersOnlyInB, HttpStatus.OK);
    }

    @PostMapping("/in-both")
    public ResponseEntity<List<Customer>> getCustomersInBothLists(@RequestBody CustomerLists customerLists) {
        List<Customer> customersInBoth = customerListService.findCustomersInBothLists(customerLists.getListA(), customerLists.getListB());
        return new ResponseEntity<>(customersInBoth, HttpStatus.OK);
    }
}



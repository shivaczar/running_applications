package com.example.demo.kafka.service;

import org.springframework.stereotype.Service;

@Service
public interface KafkaService<T> {
    void publish(String topic, String key, T message);
}

package com.example.demo.model;


import lombok.Data;

import java.util.List;

@Data
public class Customer {
    private String customerId;
    private String firstName;
    private String lastName;
    private int age;
    private double spendingLimit;
    private String mobileNumber;
    private List<Address> address;
}
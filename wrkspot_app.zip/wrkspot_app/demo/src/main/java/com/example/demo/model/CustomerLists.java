package com.example.demo.model;

import lombok.Data;

import java.util.List;

@Data
public class CustomerLists {
    private List<Customer> listA;
    private List<Customer> listB;
}

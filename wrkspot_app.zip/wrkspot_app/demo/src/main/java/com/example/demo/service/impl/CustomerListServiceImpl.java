package com.example.demo.service.impl;

import com.example.demo.model.Customer;
import com.example.demo.service.interfaces.CustomerListService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerListServiceImpl implements CustomerListService {

    @Override
    public List<Customer> findCustomersOnlyInListA(List<Customer> listA, List<Customer> listB) {
        List<Customer> customersOnlyInA = new ArrayList<>();
        for (Customer customerA : listA) {
            if (!listB.contains(customerA)) {
                customersOnlyInA.add(customerA);
            }
        }
        return customersOnlyInA;
    }

    @Override
    public List<Customer> findCustomersOnlyInListB(List<Customer> listA, List<Customer> listB) {
        List<Customer> customersOnlyInB = new ArrayList<>();
        for (Customer customerB : listB) {
            if (!listA.contains(customerB)) {
                customersOnlyInB.add(customerB);
            }
        }
        return customersOnlyInB;
    }

    @Override
    public List<Customer> findCustomersInBothLists(List<Customer> listA, List<Customer> listB) {
        List<Customer> customersInBoth = new ArrayList<>();
        for (Customer customerA : listA) {
            if (listB.contains(customerA)) {
                customersInBoth.add(customerA);
            }
        }
        return customersInBoth;
    }
}



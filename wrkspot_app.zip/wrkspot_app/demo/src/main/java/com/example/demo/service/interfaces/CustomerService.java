package com.example.demo.service.interfaces;

import com.example.demo.model.Customer;
import reactor.core.publisher.Flux;

import java.util.List;

public interface CustomerService {
    Flux<Customer> createCustomers(List<Customer> customer) throws Exception;
    Flux<Customer> getCustomers(String firstName, String lastName, String city, String state);
}

package com.example.demo.service.impl;

import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.interfaces.CustomerService;
import com.example.demo.kafka.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final KafkaService<Customer> kafkaService;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository, KafkaService<Customer> kafkaService) {
        this.customerRepository = customerRepository;
        this.kafkaService = kafkaService;
    }

    @Override
    @Transactional
    public Flux<Customer> createCustomers(List<Customer> customers) {
        System.out.println("3333333333333333333333333");
        System.out.println(customers.get(0));
        System.out.println("3333333333333333333333333");
        return Flux.fromIterable(customers)
                .flatMap(customer -> customerRepository.save(customer)
                        .doOnNext(savedCustomer -> publishToKafka(savedCustomer))
                        .onErrorResume(e -> {
                            // Log the error or handle it accordingly
                            return Mono.error(new Exception("Failed to create customer: " + e.getMessage()));
                        }))
                .collectList()
                .flatMapMany(Flux::fromIterable);
    }

    @Override
    public Flux<Customer> getCustomers(String firstName, String lastName, String city, String state) {
        try {
            if (firstName != null && !firstName.isEmpty()) {
                return customerRepository.findByFirstName(firstName);
            } else if (lastName != null && !lastName.isEmpty()) {
                return customerRepository.findByLastName(lastName);
            } else if (city != null && !city.isEmpty()) {
                return customerRepository.findByAddressCity(city);
            } else if (state != null && !state.isEmpty()) {
                return customerRepository.findByAddressState(state);
            } else {
                return customerRepository.findAll();
            }
        } catch (Exception e) {
            log.error("Error occurred while fetching customers: {}", e.getMessage());
            return Flux.empty();
        }
    }

    private void publishToKafka(Customer customer) {
        try {
            kafkaService.publish("customer_topic", customer.getCustomerId(), customer);
        } catch (Exception e) {
            // Log the error or handle it accordingly
            e.printStackTrace();
        }
    }
}




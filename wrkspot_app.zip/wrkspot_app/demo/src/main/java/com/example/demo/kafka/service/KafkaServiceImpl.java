package com.example.demo.kafka.service;

import com.example.demo.kafka.service.KafkaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaServiceImpl<T> implements KafkaService<T> {

    private final KafkaTemplate<String, T> kafkaTemplate;

    @Autowired
    public KafkaServiceImpl(KafkaTemplate<String, T> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void publish(String topic, String key, T message) {
        kafkaTemplate.send(topic, key, message);
    }
}


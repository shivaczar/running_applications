package com.example.demo.service.interfaces;


import com.example.demo.model.Customer;

import java.util.List;

public interface CustomerListService {
    List<Customer> findCustomersOnlyInListA(List<Customer> listA, List<Customer> listB);
    List<Customer> findCustomersOnlyInListB(List<Customer> listA, List<Customer> listB);
    List<Customer> findCustomersInBothLists(List<Customer> listA, List<Customer> listB);
}


# Customer Application
This is a repository for customer Application

# How to run (Docker setup is required to have Kafka functionality)

docker network create my_network

docker run -d --name zookeeper --network=my_network -p 2181:2181 zookeeper:latest

docker run -d --name kafka --network=my_network -p 9092:9092 -e KAFKA_ADVERTISED_HOST_NAME=localhost -e KAFKA_ADVERTISED_PORT=9092 -e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 -e KAFKA_CREATE_TOPICS="customer_topic:1:1" wurstmeister/kafka

docker exec -it kafka /bin/bash

docker exec -it kafka /opt/kafka/bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic customer_topic

docker run -d --name kafka --network=my_network -p 9092:9092 -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 -e KAFKA_LISTENERS=PLAINTEXT://0.0.0.0:9092 -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT -e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 -e KAFKA_CREATE_TOPICS="customer_topic:1:1"  wurstmeister/kafka

docker exec -it kafka /bin/bash

cd /opt/kafka/bin/

./kafka-topics.sh --list --bootstrap-server localhost:9092

kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic customer_topic --from-beginning


